import parent


print(locals())